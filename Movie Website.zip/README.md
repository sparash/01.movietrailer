# ud036_StarterCode
Source code for a Movie Trailer website.
# Fresh Tomatoes Trailer
This project makes a website which _Displays movie poster and trailers._

# Benifits
**With the terminal:**
>1. We can easily clone the directory without any difficulties.
>2. We can navigate the directory .cd REPOSITORY-NAME.
>3. Next step is to run python `entertainment_center.py`.

**With the IDLE:**
>1. Open the IDLE.
>2. Go to the menu bar and click on _Run_.
>3. In the _Run_ module click on _Run Module_ or _Press F5_ on your keyboard.

# Modules
The modules present in this project are:
1. `media.py`
> It defines instances and methods of class.
2. `entertainment.py`
> It is one of the most important and it is used to visit the site. It also contain the movies wich are displayed in the site. It imports `media.py` and another extention named as `fresh_tomatoes.py`
3. `fresh_tomatoes.py`
> It builds **HTML** and **CSS** content of the site and also opens the content, which is one clicked can open the _youtube windows_ in the floating windows.